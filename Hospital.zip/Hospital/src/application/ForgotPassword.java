package application;

import java.io.IOException;
import java.sql.SQLException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class ForgotPassword extends PatientProfile{

	@FXML
    private Button ChangePassword;
    
    @FXML
    private TextField ConfirmPass;

    @FXML
    private Label ConfimrPasswordLabel;

    @FXML
    private Label PasswordLabel;
    
    @FXML
    private TextField Email;

    @FXML
    private TextField NewPass;
    
    Main sc = new Main();
    
    DatabaseConnection jdb = DatabaseConnection.getInstance();
 
    @FXML
    void changePassword(ActionEvent event) throws SQLException, IOException {
    	CheckPasswordValidation();
        CheckifAllIsEmpty();
		CheckifOneIsEmpty();
		RemoveLabelIfFilled();
		 if(CheckifAllIsEmpty() && CheckifOneIsEmpty() && CheckPasswordValidation() && CheckIfPasswordsMatch()) {
    		jdb.changePassword(Login.id, NewPass.getText());	
    		sc.changeScene("PatientProfile");
		 }
		 else {
	     		CheckifAllIsEmpty();
	     		CheckifOneIsEmpty();
	     		RemoveLabelIfFilled();
	     		CheckPasswordValidation();
	     		CheckIfPasswordsMatch();
	     	}
    }
    
    private boolean CheckifAllIsEmpty() {
    	if (NewPass.getText().isEmpty() && ConfirmPass.getText().isEmpty()) {
    		
        	PasswordLabel.setText("Please enter a password");
        	ConfimrPasswordLabel.setText("Please enter your password to confirm");
    
        	return false;
    	}
		return true;
    }
    private boolean CheckifOneIsEmpty() {

        boolean validTextFields = true;

        if (NewPass.getText().isEmpty()) {
            validTextFields = false;
            PasswordLabel.setText("Please enter a password");
        }
        
        if (ConfirmPass.getText().isEmpty()) {
            validTextFields = false;
            ConfimrPasswordLabel.setText("Please enter your password to confirm");
            
        }
     

        return validTextFields;
    }
    
    private boolean CheckIfPasswordsMatch() {
    	if (!NewPass.getText().toString().equals(ConfirmPass.getText().toString())){
	        	ConfimrPasswordLabel.setText("The passwords don't match");
	            return false;
	    }
    	else {
	    return true;   
    	}
    }
	private boolean CheckPasswordValidation() {
			 
	        // for checking if password length
	        // is between 8 and 15
	        if (!((NewPass.getText().toString().length() >= 8)
	              && (NewPass.getText().toString().length() <= 15))) {
	        	PasswordLabel.setText("Please provide a password with at characters ranging between 8 and 15,\n with at least 1 small letter, 1 capital letter, 1 digit number and without spaces");
	            return false;
	        }
	 
	        // to check space
	        if (NewPass.getText().toString().contains(" ")) {
	        	PasswordLabel.setText("Please provide a password with at characters ranging between 8 and 15,\n with at least 1 small letter, 1 capital letter, 1 digit number and without spaces");
	            return false;
	        }
	        if (true) {
	            int count = 0;
	 
	            // check digits from 0 to 9
	            for (int i = 0; i <= 9; i++) {
	 
	                // to convert int to string
	                String str1 = Integer.toString(i);
	 
	                if (NewPass.getText().toString().contains(str1)) {
	                    count = 1;
	                }
	            }
	            if (count == 0) {
	            	PasswordLabel.setText("Please provide a password with at characters ranging between 8 and 15,\n with at least 1 small letter, 1 capital letter, 1 digit number and without spaces");
	                return false;
	            }
	        }
	 
	        // for special characters
	        if (!(NewPass.getText().toString().contains("@") || (NewPass.getText().toString().contains("#")
	              || NewPass.getText().toString().contains("!") || NewPass.getText().toString().contains("~")
	              || NewPass.getText().toString().contains("$") || NewPass.getText().toString().contains("%")
	              || NewPass.getText().toString().contains("^") || NewPass.getText().toString().contains("&")
	              || NewPass.getText().toString().contains("*") || NewPass.getText().toString().contains("(")
	              || NewPass.getText().toString().contains(")") || NewPass.getText().toString().contains("-")
	              || NewPass.getText().toString().contains("+") || NewPass.getText().toString().contains("/")
	              || NewPass.getText().toString().contains(":") || NewPass.getText().toString().contains(".")
	              || NewPass.getText().toString().contains(", ") ||NewPass.getText().toString().contains("<")
	              || NewPass.getText().toString().contains(">") || NewPass.getText().toString().contains("?")
	              || NewPass.getText().toString().contains("|")))) {
	        	PasswordLabel.setText("Please provide a password with at characters ranging between 8 and 15,\n with at least 1 small letter, 1 capital letter, 1 digit number and without spaces");
	            return false;
	        }
	 
	        if (true) {
	            int count = 0;
	 
	            // checking capital letters
	            for (int i = 65; i <= 90; i++) {
	 
	                // type casting
	                char c = (char)i;
	 
	                String str1 = Character.toString(c);
	                if (NewPass.getText().toString().contains(str1)) {
	                    count = 1;
	                }
	            }
	            if (count == 0) {
	            	PasswordLabel.setText("Please provide a password with at characters ranging between 8 and 15,\n with at least 1 small letter, 1 capital letter, 1 digit number and without spaces");
	                return false;
	            }
	        }
	 
	        if (true) {
	            int count = 0;
	 
	            // checking small letters
	            for (int i = 97; i <= 122; i++) {
	 
	                // type casting
	                char c = (char)i;
	                String str1 = Character.toString(c);
	 
	                if (NewPass.getText().toString().contains(str1)) {
	                    count = 1;
	                }
	            }
	            if (count == 0) {
	            	PasswordLabel.setText("Please provide a password with at characters ranging between 8 and 15,\n with at least 1 small letter, 1 capital letter, 1 digit number and without spaces");
	                return false;
	            }
	        }
	 
	        // if all conditions fails
	        return true;
	    }

	private boolean RemoveLabelIfFilled() {
		boolean validTextFields = true;
		
        if (!NewPass.getText().isEmpty()) {
            validTextFields = false;
            PasswordLabel.setText("");
            
        }
        
        if (!ConfirmPass.getText().isEmpty()) {
            validTextFields = false;
            ConfimrPasswordLabel.setText("");
            
        }
     

        return validTextFields;
	}
}
