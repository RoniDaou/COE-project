package application;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class DoctorLogin extends DatabaseConnection{

    @FXML
    private Button BackButton;

    @FXML
    private Label InvalidPasswordLabel;

    @FXML
    private Label InvalidUsernameLabel;

    @FXML
    private Button LoginButton;

    @FXML
    private TextField Username;

    @FXML
    private PasswordField password;

    @FXML
    private Label InvalidPasswordLabel2;

    @FXML
    private Label InvalidUsernameLabel2;
    
    Main sc = new Main();
    @FXML
    void Login(ActionEvent event) throws IOException,SQLException {
    	try (Connection connection = DriverManager.getConnection(DATABASE_URL, DATABASE_USERNAME, DATABASE_PASSWORD);

                PreparedStatement preparedStatement = connection.prepareStatement(InsertingQUERY)) {
                preparedStatement.setString(1, Username.getText());
                preparedStatement.setString(2, password.getText());


                ResultSet resultSet = preparedStatement.executeQuery();
                if (resultSet.next()) {
                    sc.changeScene("InsertingAppointments.fxml");
                	
                }
                else {
                	Username.setText("");
                	password.setText("");
                	InvalidUsernameLabel2.setText("Invalid Username");
          		    InvalidPasswordLabel2.setText("Invalid password");
                }

            } catch (SQLException e1) {
                // print SQL exception information
            	e1.printStackTrace();
            }
    }

    @FXML
    void Undo(ActionEvent event) throws IOException {
    	sc.changeScene("AccountType.fxml");
    }

}