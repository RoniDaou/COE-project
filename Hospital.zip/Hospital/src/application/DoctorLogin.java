package application;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class DoctorLogin{
	public static int id;

    @FXML
    private Button BackButton;

    @FXML
    private Button LoginButton;

    @FXML
    private TextField Username;

    @FXML
    private PasswordField password;

    @FXML
    private Label InvalidPasswordLabel;

    @FXML
    private Label InvalidUsernameLabel;
    
    DatabaseConnection jdb = DatabaseConnection.getInstance();
    
    Main sc = new Main();
    @FXML
    void Login(ActionEvent event) throws IOException,SQLException {
    	if(jdb.loginDoctors(Username.getText(), password.getText())) {
    		sc.changeScene("InsertingAppointments.fxml");
		}else {
        	Username.setText("");
        	password.setText("");
        	InvalidUsernameLabel.setText("Invalid Username");
  		    InvalidPasswordLabel.setText("Invalid password");
        }

    }
   

    @FXML
    void Undo(ActionEvent event) throws IOException {
    	sc.changeScene("AccountType.fxml");
    }

}