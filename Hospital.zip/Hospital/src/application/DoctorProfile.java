package application;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class DoctorProfile implements Initializable{

    @FXML
    private TextField EmailAddress;

    @FXML
    private TextField Passcode;

    @FXML
    private Button Profile;

    @FXML
    private Button Signout;

    DatabaseConnection jdb = DatabaseConnection.getInstance();
    
    Main sc = new Main();
    
    @FXML
    void SignOut(ActionEvent event) throws IOException {
    	sc.changeScene("DoctorLogin.fxml");
    }

    @FXML
    void ViewProfile(ActionEvent event) throws IOException {
    	sc.changeScene("DoctorProfile.fxml");
    }
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		Profile.getStyleClass().add("viewDoctorProfile");
		String[] info;
		try {
			info = jdb.getDoctorProfileInfo(DoctorLogin.id);
			EmailAddress.setText(info[0]);
			Passcode.setText(info[1]);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
