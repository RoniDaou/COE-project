package application;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;


public class Login{
	
        public static int id;
        
	    @FXML
	    private Button LoginButton,RegisterButton;

	    @FXML
	    private TextField Username;
	    
	    @FXML
	    private PasswordField password;
	    
	    @FXML
	    private Button Back;
	    
	    @FXML
	    private Label PageInfo;
	    
	    Main sc = new Main();
	    
	    @FXML
	    private Label InvalidPasswordLabel;

	    @FXML
	    private Label InvalidUsernameLabel;
	    
	    @FXML
	    private Button forgotPassword;
	    
	    DatabaseConnection jdb = DatabaseConnection.getInstance();
	    
    @FXML
    public void Login(ActionEvent e) throws IOException, SQLException{
    		if(jdb.loginPatients(Username.getText(), password.getText())) {
        		sc.changeScene("PatientProfile.fxml");
    		}else {
            	Username.setText("");
            	password.setText("");
            	InvalidUsernameLabel.setText("Invalid Username");
      		    InvalidPasswordLabel.setText("Invalid password");
            }

     
        }
        
    @FXML
    void SignUp(ActionEvent event) throws IOException {
    	
    	sc.changeScene("SignUp.fxml");
    	
    }
    
    @FXML
    void forgotPassword(ActionEvent event) throws IOException {
    	sc.changeScene("ForgotPass.fxml");
    	
    }
    
    @FXML
    void Undo(ActionEvent event) throws IOException {
    	sc.changeScene("AccountType.fxml");
    }
}
