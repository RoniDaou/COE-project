package application;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;


public class Login extends DatabaseConnection{
	
        private static final String SELECT_QUERY = "SELECT * FROM patient WHERE Email = ? and Password = ?";
        
	    @FXML
	    private Button LoginButton,RegisterButton;

	    @FXML
	    private TextField Username;
	    
	    @FXML
	    private PasswordField password;
	    
	    @FXML
	    private Button Back;
	    
	    @FXML
	    private Label PageInfo;
	    
	    Main sc = new Main();
	    
    @FXML
    public void Login(ActionEvent e) throws IOException, SQLException{
  
    	try (Connection connection = DriverManager.getConnection(DATABASE_URL, DATABASE_USERNAME, DATABASE_PASSWORD);

                PreparedStatement preparedStatement = connection.prepareStatement(SELECT_QUERY)) {
                preparedStatement.setString(1, Username.getText());
                preparedStatement.setString(2, password.getText());


                ResultSet resultSet = preparedStatement.executeQuery();
                if (resultSet.next()) {
                    sc.changeScene("BookingAppointments.fxml");
                }
                else {
                	Username.setText("");
                	password.setText("");
                	PageInfo.setText("		Invalid input, please try again!");
                }

            } catch (SQLException e1) {
                // print SQL exception information
            	e1.printStackTrace();
            }
        }
        
    @FXML
    void SignUp(ActionEvent event) throws IOException {
    	
    	sc.changeScene("SignUp.fxml");
    	
    }
    
    @FXML
    void Undo(ActionEvent event) throws IOException {
    	sc.changeScene("AccountType.fxml");
    }
}
