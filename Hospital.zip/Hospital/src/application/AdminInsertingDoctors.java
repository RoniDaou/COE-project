package application;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Window;

public class AdminInsertingDoctors implements Initializable {

    @FXML
    private ChoiceBox<String> BloodGroup;

    @FXML
    private DatePicker DateOfJoining;

    @FXML
    private ChoiceBox<String> Gender;

    @FXML
    private Button NewDoctor;

    @FXML
    private TextField Password;

    @FXML
    private Button Save;

    @FXML
    private TextField Username;

    @FXML
    private TextField speciality;
    
    @FXML
    private Button Undo;
    
    Main sc = new Main();
    
    String [] BloodType = {"A", "B", "AB" ,"O"};
    String [] gender_specific = {"M","F"};
    
    public void initialize(URL arg0, ResourceBundle arg1) {
    	Gender.setValue("None");
		Gender.getItems().addAll(gender_specific);
    	BloodGroup.getItems().addAll(BloodType);
    }
    
    @FXML
    void undo(ActionEvent event) throws IOException {
    	sc.changeScene("AdminLogin.fxml");
    }
    
    @FXML
    void newDoctor(ActionEvent event) {
       BloodGroup.setValue(null);

       DateOfJoining.setValue(null);

       Gender.setValue(null);


       Password.setText("");

       Username.setText("");

       speciality.setText("");
    }

    @FXML
    void save(ActionEvent event) {
    	
    	Window owner = Save.getScene().getWindow();
    	
    	String username = Username.getText();
        String password = Password.getText();
        String gender = Gender.getValue().toString();
        LocalDate value = DateOfJoining. getValue();
        String dateOfJoining = value.toString();
        String bloodGroup = BloodGroup.getValue().toString();
        String Speciality = speciality.getText();
        

        DatabaseConnection jd = new DatabaseConnection();
        jd.insertRec(username, password, gender, dateOfJoining, bloodGroup, Speciality);
    	
        showAlert(Alert.AlertType.CONFIRMATION, owner, "Doctor Successfully Added!",
                "Welcome");
    }
    

    private static void showAlert(Alert.AlertType alertType, Window owner, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.initOwner(owner);
        alert.show();
    }
    
}
