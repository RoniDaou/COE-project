package application;

import java.awt.event.InputMethodEvent;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;

public class AccountType implements Initializable{

    @FXML
    private ChoiceBox<String> Account;

    @FXML
    private Button Proceed;
    
    Main scene =new Main();
   
    String []accounts = {"Admin", "Doctor", "Patient"};
    
    @FXML
    void Proceed(ActionEvent e) throws IOException {
    	if(Account.getValue().equals("Doctor")) {
    		scene.changeScene("AdminLogin.fxml");
    	}
    	else if(Account.getValue().equals("Patient")) {
    		scene.changeScene("Login.fxml");
    	}
    	else if(Account.getValue().equals("Admin")){
    		//scene.changeScene(".fxml");
    	}
    }

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		Account.setValue("Accounts");
		Account.getItems().addAll(accounts);
		
	}

}
