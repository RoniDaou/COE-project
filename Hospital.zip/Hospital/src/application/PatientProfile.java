package application;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class PatientProfile implements Initializable{

    @FXML
    protected Button Appointments;

    @FXML
    protected Button BookAnAppointment;

    @FXML
    protected Button Profile;

    @FXML
    protected Button Signout;

    @FXML
    protected TextField EmailAddress;

    @FXML
    protected TextField FullName;

    @FXML
    protected TextField Passcode;
    
    Main sc = new Main();
    
    
    @FXML
    void BookAppointment(ActionEvent event) throws IOException {
    	sc.changeScene("BookingAppointment.fxml");
    }

    @FXML
    void SignOut(ActionEvent event) throws IOException {
    	sc.changeScene("Login.fxml");
    }

    @FXML
    void ViewProfile(ActionEvent event) throws IOException {
    	sc.changeScene("PatientProfile.fxml");
    }

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {	
		Profile.getStyleClass().add("viewProfile");	
	}

}