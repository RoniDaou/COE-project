package application;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class PatientProfile implements Initializable{

    @FXML
    protected Button Appointments;

    @FXML
    protected Button BookAnAppointment;

    @FXML
    protected Button Profile;

    @FXML
    protected Button Signout;

    @FXML
    protected TextField EmailAddress;

    @FXML
    protected TextField FullName;

    @FXML
    protected TextField Passcode;
    
    @FXML
    private Button changePass;
    
    Main sc = new Main();
    
    DatabaseConnection jdb = DatabaseConnection.getInstance();
    
    @FXML
    void BookAppointment(ActionEvent event) throws IOException {
    	sc.changeScene("BookingAppointment.fxml");
    }

    @FXML
    void SignOut(ActionEvent event) throws IOException {
    	sc.changeScene("Login.fxml");
    }

    @FXML
    void ViewProfile(ActionEvent event) throws IOException, SQLException {
    	//jdb.getProfileInfo(FullName, Passcode);
    	sc.changeScene("PatientProfile.fxml");
    }

    @FXML
    void ChangePassword(ActionEvent event) throws IOException {
    	sc.changeScene("ForgotPassword.fxml");
    }
    
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {	
		Profile.getStyleClass().add("viewProfile");	
	}

}