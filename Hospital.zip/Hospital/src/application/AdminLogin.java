package application;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.InputMethodEvent;

public class AdminLogin {

    @FXML
    private Button BackButton;

    @FXML
    private Button LoginButton;

    @FXML
    private TextField Username;

    @FXML
    private PasswordField password;

    Main scene = new Main();
      @FXML
    void Login(ActionEvent event) {

    }

    @FXML
    void Undo(ActionEvent event) throws IOException {
    	scene.changeScene("AccountType.fxml");
    }

}
