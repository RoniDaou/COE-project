package application;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Labeled;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class ForgotPass implements Initializable{

    @FXML
    private Button Back;

    @FXML
    private Button ChangePassword;

    @FXML
    private TextField ConfirmPassword;

    @FXML
    private Label ConfirmPasswordLabel;

    @FXML
    private Label UserLabel;

    @FXML
    private Label NewPasswordLabel;

    @FXML
    private PasswordField Newpassword;

    @FXML
    private TextField Username;

    
    DatabaseConnection jdb = DatabaseConnection.getInstance();
    
    Main sc = new Main();
    
    GmailSender mail = new GmailSender();
    String email = null;
    
    @Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		String[] info;
		try {
			info = jdb.getPatientProfileInfo(Login.id);
			email = info[1];
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
    
    @FXML
    void Undo(ActionEvent event) throws IOException {
    	sc.changeScene("Login.fxml");
    }

    @FXML
    void changePassword(ActionEvent event) throws SQLException, IOException {
    	CheckPasswordValidation();
        CheckifAllIsEmpty();
		CheckifOneIsEmpty();
		RemoveLabelIfFilled();
		 
			 if(!jdb.checkIfPatientExist(Username.getText())) {
				 UserLabel.setText("Invalid E-mail Address");
			 }
			 else {
			if(CheckifAllIsEmpty() && CheckifOneIsEmpty() && CheckPasswordValidation() && CheckIfPasswordsMatch()) {
				 mail.send(email, "Your Medical password has been reseted", "This is a confirmation that the password for your Hospital account roni_daou has just been reseted.\r\n"
		    				+ "\r\n"
		    				+ "If you didn't reset your password, please contact the hospital on this email for security reasons.");
				 sc.changeScene("Login.fxml");
			 }
		 else {
	     		CheckifAllIsEmpty();
	     		CheckifOneIsEmpty();
	     		RemoveLabelIfFilled();
	     		CheckPasswordValidation();
	     		CheckIfPasswordsMatch();
	     	}
			 }
    }
    
    private boolean CheckifAllIsEmpty() {
    	if (Username.getText().isEmpty() && Newpassword.getText().isEmpty() && Username.getText().isEmpty()) {
    		
    		NewPasswordLabel.setText("Please enter a password");
        	ConfirmPasswordLabel.setText("Please enter your password to confirm");
    
        	return false;
    	}
		return true;
    }
    private boolean CheckifOneIsEmpty() {

        boolean validTextFields = true;

        if(Username.getText().isEmpty()) {
        	validTextFields = false;
            UserLabel.setText("Please Enter you Email");
        }
        if (Newpassword.getText().isEmpty()) {
            validTextFields = false;
            NewPasswordLabel.setText("Please enter a password");
        }
        
        if (ConfirmPassword.getText().isEmpty()) {
            validTextFields = false;
            ConfirmPasswordLabel.setText("Please enter your password to confirm");
            
        }
     

        return validTextFields;
    }
    
    private boolean CheckIfPasswordsMatch() {
    	if (!Newpassword.getText().toString().equals(ConfirmPassword.getText().toString())){
	        	ConfirmPasswordLabel.setText("The passwords don't match");
	            return false;
	    }
    	else {
	    return true;   
    	}
    }
	private boolean CheckPasswordValidation() {
			 
	        // for checking if password length
	        // is between 8 and 15
	        if (!((Newpassword.getText().toString().length() >= 8)
	              && (Newpassword.getText().toString().length() <= 15))) {
	        	NewPasswordLabel.setText("Please provide a password with at characters ranging between 8 and 15,\n with at least 1 small letter, 1 capital letter, 1 digit number and without spaces");
	            return false;
	        }
	 
	        // to check space
	        if (Newpassword.getText().toString().contains(" ")) {
	        	NewPasswordLabel.setText("Please provide a password with at characters ranging between 8 and 15,\n with at least 1 small letter, 1 capital letter, 1 digit number and without spaces");
	            return false;
	        }
	        if (true) {
	            int count = 0;
	 
	            // check digits from 0 to 9
	            for (int i = 0; i <= 9; i++) {
	 
	                // to convert int to string
	                String str1 = Integer.toString(i);
	 
	                if (Newpassword.getText().toString().contains(str1)) {
	                    count = 1;
	                }
	            }
	            if (count == 0) {
	            	NewPasswordLabel.setText("Please provide a password with at characters ranging between 8 and 15,\n with at least 1 small letter, 1 capital letter, 1 digit number and without spaces");
	                return false;
	            }
	        }
	 
	        // for special characters
	        if (!(Newpassword.getText().toString().contains("@") || (Newpassword.getText().toString().contains("#")
	              || Newpassword.getText().toString().contains("!") || Newpassword.getText().toString().contains("~")
	              || Newpassword.getText().toString().contains("$") || Newpassword.getText().toString().contains("%")
	              || Newpassword.getText().toString().contains("^") || Newpassword.getText().toString().contains("&")
	              || Newpassword.getText().toString().contains("*") || Newpassword.getText().toString().contains("(")
	              || Newpassword.getText().toString().contains(")") || Newpassword.getText().toString().contains("-")
	              || Newpassword.getText().toString().contains("+") || Newpassword.getText().toString().contains("/")
	              || Newpassword.getText().toString().contains(":") || Newpassword.getText().toString().contains(".")
	              || Newpassword.getText().toString().contains(", ") ||Newpassword.getText().toString().contains("<")
	              || Newpassword.getText().toString().contains(">") || Newpassword.getText().toString().contains("?")
	              || Newpassword.getText().toString().contains("|")))) {
	        	NewPasswordLabel.setText("Please provide a password with at characters ranging between 8 and 15,\n with at least 1 small letter, 1 capital letter, 1 digit number and without spaces");
	            return false;
	        }
	 
	        if (true) {
	            int count = 0;
	 
	            // checking capital letters
	            for (int i = 65; i <= 90; i++) {
	 
	                // type casting
	                char c = (char)i;
	 
	                String str1 = Character.toString(c);
	                if (Newpassword.getText().toString().contains(str1)) {
	                    count = 1;
	                }
	            }
	            if (count == 0) {
	            	NewPasswordLabel.setText("Please provide a password with at characters ranging between 8 and 15,\n with at least 1 small letter, 1 capital letter, 1 digit number and without spaces");
	                return false;
	            }
	        }
	 
	        if (true) {
	            int count = 0;
	 
	            // checking small letters
	            for (int i = 97; i <= 122; i++) {
	 
	                // type casting
	                char c = (char)i;
	                String str1 = Character.toString(c);
	 
	                if (Newpassword.getText().toString().contains(str1)) {
	                    count = 1;
	                }
	            }
	            if (count == 0) {
	            	NewPasswordLabel.setText("Please provide a password with at characters ranging between 8 \n and 15, with at least 1 small letter, 1 capital letter, 1 digit number\n and without spaces");
	                return false;
	            }
	        }
	 
	        // if all conditions fails
	        return true;
	    }

	private boolean RemoveLabelIfFilled() {
		boolean validTextFields = true;
		
        if (!Newpassword.getText().isEmpty()) {
            validTextFields = false;
            NewPasswordLabel.setText("");
            
        }
        
        if(!Username.getText().isEmpty()) {
        	validTextFields = false;
            UserLabel.setText("");
        }
        
        if (!ConfirmPassword.getText().isEmpty()) {
            validTextFields = false;
            NewPasswordLabel.setText("");
            
        }
     

        return validTextFields;
	}
}

