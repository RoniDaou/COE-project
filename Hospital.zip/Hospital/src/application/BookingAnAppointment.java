package application;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.awt.*;

import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.input.InputMethodEvent;

	public class BookingAnAppointment extends PatientProfile implements Initializable{
	
		@FXML
	    private DatePicker Day_Slot;

	    @FXML
	    private ChoiceBox<String> Department;

	    @FXML
	    private ChoiceBox<String> Doctor_name;

	    @FXML
	    private ChoiceBox<String> Time_Slot;
	    
	    @FXML
	    private Button BookAnAppointment;
	    
	    @FXML
	    private Button Profile;

	    @FXML
	    private Button Signout;

	    //@FXML
	    //private Label TimeConflict;
	    
	    @FXML
	    private Button BookAppointment;
	    
	    public static int doc_id;
	    
	    DatabaseConnection jdb = DatabaseConnection.getInstance();
	    
	    Main sc = new Main();
		
	    String[] department = {"Neurologist", "Psychiatrist",  "Dermatology","Cardiologist", "Orthopedic"};
	    String [] TimesAvailable = {"8:00 am","9:00 am","10:00 am","11:00 am","12:00 pm","1:00 pm","2:00 pm","3:00 pm","4:00 pm","5:00 pm"};
	    HashMap<String, String> timeMap = new HashMap<>();
	  
	    String[] toRemove;

	    GmailSender sendmail = new GmailSender();
	    
	    public void initialize(URL arg0, ResourceBundle arg1) {
	    	BookAnAppointment.getStyleClass().add("bookAppointments");	
	    	timeMap.put("8:00 am", "9:00 am");
	    	timeMap.put("9:00 am", "10:00 am");
	    	timeMap.put("10:00 am", "11:00 am");
	    	timeMap.put("11:00 am", "12:00 pm");
	    	timeMap.put("12:00 pm", "1:00 pm");
	    	timeMap.put("1:00 pm", "2:00 pm");
	    	timeMap.put("2:00 pm", "3:00 pm");
	    	timeMap.put("3:00 pm", "4:00 pm");
	    	timeMap.put("4:00 pm", "5:00 pm");
	    	timeMap.put("5:00 pm", "6:00 pm");
	    	Department.setValue("None");
	    	Department.getItems().addAll(department);
	    	Time_Slot.getItems().addAll(TimesAvailable);

	    	Department.getSelectionModel().selectedItemProperty().addListener
	    	( (ObservableValue<? extends String> observable, String oldValue, String newValue) -> Doctor_name.getItems().clear());
	    	Department.getSelectionModel().selectedItemProperty().addListener
	    	( (ObservableValue<? extends String> observable, String oldValue, String newValue)
	    			-> {
						try {
							Doctor_name.getItems().addAll(jdb.getDoctorsNames(newValue));
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					} );
	    	
		}
	    
	    @FXML
	    public void getDate(ActionEvent event) throws SQLException {
	    	Time_Slot.getItems().clear();
	    	doc_id = jdb.getDoctorId(Doctor_name.getValue(), Department.getValue());
	    	toRemove = jdb.check_appointments(Day_Slot.getValue().toString(), doc_id);
	    	Time_Slot.getItems().addAll(TimesAvailable);
	    	for(String time : toRemove) {
	    		System.out.println(time);
	    		Time_Slot.getItems().remove(time);
	    	}
	    	
	    }
	    
	    @FXML
	    void Book(ActionEvent event) throws SQLException, IOException {
	    	String end = timeMap.get(Time_Slot.getValue());
	    	jdb.bookAppointment(Login.id, doc_id, Time_Slot.getValue(), end, Day_Slot.getValue().toString());
	    	sc.changeScene("BookingAppointment.fxml");
	    	//sendmail.send("roni.r.daou@gmail.com", "hello", "World");
	    	//sendmail.send("shihab.azzam27@gmail.com", "hello", "World");
	    }
		
	}

