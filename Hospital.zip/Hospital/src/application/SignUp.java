package application;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Window;

public class SignUp implements Initializable{

 
    String gender[] = {"Male", "Female"};
    
    @FXML
    private TextField Allergies;

    @FXML
    private TextField ConfirmPassword;

    @FXML
    private Label ConfirmPasswordLabel;

    @FXML
    private DatePicker DateOfBirth;

    @FXML
    private Label DateOfBirthLabel;

    @FXML
    private TextField Email;

    @FXML
    private Label EmailLabel;

    @FXML
    private TextField FirstName;

    @FXML
    private Label FirstNameLabel;

    @FXML
    private ChoiceBox<String> Gender;

    @FXML
    private Label GenderLabel;

    @FXML
    private TextField LastName;

    @FXML
    private Label LastNameLabel;

    @FXML
    private TextField Medications;

    @FXML
    private TextField Password;

    @FXML
    private Label PasswordLabel;

    @FXML
    private Button Submit;

    @FXML
    private Button Undo;

    Main sc = new Main();
    
    
    @FXML
    void Undo(ActionEvent event) throws IOException {
    	sc.changeScene("Login.fxml");
    }
    
	public void initialize(URL arg0, ResourceBundle arg1) {
		Gender.setValue("None");
		Gender.getItems().addAll(gender);
		
	}
    @FXML
    public void Submit(ActionEvent event) throws SQLException,IOException {

        Window owner = Submit.getScene().getWindow();
        
       
        if (Email.getText().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, owner, "Form Error!",
                "Please enter your email id");
            return;
        }
        if (Password.getText().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, owner, "Form Error!",
                "Please enter a password");
            return;
        }
	  
 	    if (FirstName.getText().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, owner, "Form Error!",
                "Please enter your first name");
            return;
        }
	    if (LastName.getText().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, owner, "Form Error!",
                "Please enter your last name");
            return;
        }
 	    if (Gender.getValue().toString()=="None") {
            GenderLabel.setText(
                "Please select your gender");
            return;
        }
 	    if (DateOfBirth.getValue()==null) {
            showAlert(Alert.AlertType.ERROR, owner, "Form Error!",
                "Please enter your date of birth");
            return;
        }
	    //if (Password.getText().toString() != ConfirmPassword.getText().toString()) {
          //  showAlert(Alert.AlertType.ERROR, owner, "Form Error!",
           //     "Passwords do not match");
          //  return;
        //}

        String email = Email.getText();
        String password = Password.getText();
        String firstName = FirstName.getText();
        String lastName = LastName.getText();
        String confirmPassword = ConfirmPassword.getText();
        String gender = Gender.getValue().toString();
        LocalDate value = DateOfBirth. getValue();
        String dateOfBirth = value.toString();
        String medications = Medications.getText();
        String allergies = Allergies.getText();
        

        DatabaseConnection jdb = new DatabaseConnection();
        jdb.insertRecord(firstName, lastName, email, password, confirmPassword, gender, dateOfBirth, medications, allergies);

        showAlert(Alert.AlertType.CONFIRMATION, owner, "Registration Successful!",
            "Welcome");
        sc.changeScene("Login.fxml");
    }

    private static void showAlert(Alert.AlertType alertType, Window owner, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.initOwner(owner);
        alert.show();
    }
}