package application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;

import javafx.scene.control.ChoiceBox;

public class DatabaseConnection {

    protected static final String DATABASE_URL = "jdbc:mysql://localhost:3306/sqlconnection";
    protected static final String DATABASE_USERNAME = "root";
    protected static final String DATABASE_PASSWORD = "tigHootE005";
    protected static final String INSERT_QUERY = "INSERT INTO patient (FirstName, LastName, Email, Password, ConfirmPassword, Gender, DateOfBirth, Medications, Allergies) VALUES (?, ?, ? , ? , ? , ? , ? , ? , ?)";
    protected static final String AdminInsertingQUERY = "INSERT INTO InsertDoctors ( username, password,  gender, dateOfJoining, bloodGroup,Speciality) VALUES (?, ?, ? , ? , ? , ?)";
    
    public void insertRecord(String FirstName, String LastName, String Email, String Password, String ConfirmPassword, String Gender, String DateOfBirth, String Medications, String Allergies
    		) throws SQLException {

        // Step 1: Establishing a Connection 
        try (
        	Connection connection = DriverManager.getConnection(DATABASE_URL, DATABASE_USERNAME, DATABASE_PASSWORD);

            // Step 2:Create a statement using connection object
            PreparedStatement preparedStatement = connection.prepareStatement(INSERT_QUERY)) {
            preparedStatement.setString(1, FirstName);
            preparedStatement.setString(2, LastName);
            preparedStatement.setString(3, Email);
            preparedStatement.setString(4, Password);
            preparedStatement.setString(5, ConfirmPassword);
            preparedStatement.setString(6, Gender);
            preparedStatement.setString(7, DateOfBirth);
            preparedStatement.setString(8, Medications);
            preparedStatement.setString(9, Allergies);
            

            System.out.println(preparedStatement);
            // Step 3: Execute the query or update query
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            // print SQL exception information
            printSQLException(e);
        }
    }

    public static void printSQLException(SQLException ex) {
        for (Throwable e: ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }

    public void insertRec(String username, String password, String gender, String dateOfJoining, String bloodGroup, String Speciality) {
    	 try (
    	        	Connection connection = DriverManager.getConnection(DATABASE_URL, DATABASE_USERNAME, DATABASE_PASSWORD);

    	            // Step 2:Create a statement using connection object
    	            PreparedStatement preparedStatement = connection.prepareStatement(AdminInsertingQUERY)) {
    	            preparedStatement.setString(1, username);
    	            preparedStatement.setString(2, password);
    	            preparedStatement.setString(3, gender);
    	            preparedStatement.setString(4, dateOfJoining);
    	            preparedStatement.setString(5, bloodGroup);
    	            preparedStatement.setString(6, Speciality);
    	    
    	            

    	            System.out.println(preparedStatement);
    	            // Step 3: Execute the query or update query
    	            preparedStatement.executeUpdate();
    	        } catch (SQLException e) {
    	            // print SQL exception information
    	            printSQLException(e);
    	        }
		
	}
}
