package application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javafx.scene.control.TextField;

public class DatabaseConnection{

    protected static final String DATABASE_URL = "jdbc:mysql://localhost:3306/sqlconnection";
    protected static final String DATABASE_USERNAME = "root";
    protected static final String DATABASE_PASSWORD = "tigHootE005";
    protected static final String LOGIN_QUERY = "SELECT * FROM patient WHERE Email = ? and Password = ?";
    protected static final String InsertingQUERY =  "SELECT * FROM insertdoctors where username = ? && password = ?";
    protected static final String AdminInsertingQUERY = "INSERT INTO insertdoctors ( username, password,  gender, dateOfJoining, bloodGroup,Speciality) VALUES (?, ?, ? , ? , ? , ?)";
    protected static final String INSERT_QUERY = "INSERT INTO patient (FirstName, LastName, Email, Password, ConfirmPassword, Gender, DateOfBirth, Medications, Allergies) VALUES (?, ?, ? , ? , ? , ? , ? , ? , ?)";
    protected static final String Doctor_Names = "select Username from insertdoctors where Speciality = ?;";
    protected static final String BOOK_APPOINMENT = "INSERT INTO appointments (patient_id, doctor_id, start_time, end_time, app_day) select"
    												+ " patient.patient_id, insertdoctors.Doctor_id, ?, ?, ? from patient, insertdoctors where patient_id = ? "
    												+ "and Doctor_id = ?;";
    protected static final String CHECK_APPOINMENT = "SELECT * FROM appointments where app_day = ? AND doctor_id = ?;";
    
    protected static final String DOCTOR_ID_QUERY = "SELECT * FROM insertdoctors WHERE username = ? AND Speciality = ?;";
    private Connection connection;
    
    protected static final String TIME_CONFLICT = "SELECT * FROM appointments WHERE patient_id = ? AND start_time = ? AND app_day = ?;";
    
    protected static final String GET_NAME_OF_DOCTOR_FOR_A_SPECIFIC_APPOINTMENT_1 = "SELECT doctor_id FROM appointments WHERE patient_id = ? AND start_time = ? AND app_day = ?;";
    
    protected static final String GET_NAME_OF_DOCTOR_FOR_A_SPECIFIC_APPOINTMENT_2 = "SELECT * FROM insertdoctors WHERE doctor_id = ?;";
    
    protected static final String CHANGE_PASSWORD = "update patient set password = ? where patient_id = ?; ";
    
    protected static final String getPatientInfo = "SELECT * FROM patients WHERE FirstName = ? And LastName = ? And Password = ?; ";
    
    protected static final String PATIENT_ID_QUERY = "SELECT * FROM patient WHERE email = ?;";
    
    private static DatabaseConnection instance = new DatabaseConnection();

    public boolean checkIfPatientExist(String email) throws SQLException {
    	PreparedStatement prep = connection.prepareStatement(PATIENT_ID_QUERY);
    	prep.setString(1, email);
    	ResultSet result = prep.executeQuery();
    
    	if(result.next()) {
    		return true;
    	}
    	return false;
    }	
    
    private DatabaseConnection() {
    	getConnection();
    }
    
    public static DatabaseConnection getInstance() {
    	return instance;
    }
    
    public void getConnection() {
    	try {
			connection = DriverManager.getConnection(DATABASE_URL, DATABASE_USERNAME, DATABASE_PASSWORD);
		} catch (SQLException e) {
			e.printStackTrace();
		}
    }
    public void changePassword(int id, String password) throws SQLException {
    	PreparedStatement prep = connection.prepareStatement(CHANGE_PASSWORD);
    	prep.setString(1, password);
    	prep.setInt(2, id);
    	prep.executeUpdate();
    }
    
    public int getPatientId(String email) throws SQLException {
    	PreparedStatement prep = connection.prepareStatement(PATIENT_ID_QUERY);
    	prep.setString(1, email);
    	ResultSet result = prep.executeQuery();
    	result.next();
    	return result.getInt("patient_id");
    }
    
    public boolean checkTimeConflict(int id, String startTime, String appDay) throws SQLException {
    	PreparedStatement prep = connection.prepareStatement(TIME_CONFLICT);
    	prep.setInt(1, id);
    	prep.setString(2, startTime);
    	prep.setString(3, appDay);
    	ResultSet result = prep.executeQuery();
    	if(result.next()) {
    		return true;
    	}
    	return false;
    }
    
    public String getDoctorNameForAnAppoitment(int id, String startTime, String appDay) throws SQLException {
    	PreparedStatement prep1 = connection.prepareStatement(GET_NAME_OF_DOCTOR_FOR_A_SPECIFIC_APPOINTMENT_1);
    	prep1.setInt(1, id);
    	prep1.setString(2, startTime);
    	prep1.setString(3, appDay);
    	ResultSet result1 = prep1.executeQuery();
    	result1.next();
    	int docId = result1.getInt("doctor_id");
    	PreparedStatement prep2 = connection.prepareStatement(GET_NAME_OF_DOCTOR_FOR_A_SPECIFIC_APPOINTMENT_2);
    	prep2.setInt(1, docId);
    	ResultSet result2 = prep2.executeQuery();
    	result2.next();
    	return result2.getString("username");    	
    }
    
    public void insertRecord(String FirstName, String LastName, String Email, String Password, String ConfirmPassword, String Gender, String DateOfBirth, String Medications, String Allergies
    		) throws SQLException {

            // Step 2:Create a statement using connection object
            PreparedStatement preparedStatement = connection.prepareStatement(INSERT_QUERY);
            preparedStatement.setString(1, FirstName);
            preparedStatement.setString(2, LastName);
            preparedStatement.setString(3, Email);
            preparedStatement.setString(4, Password);
            preparedStatement.setString(5, ConfirmPassword);
            preparedStatement.setString(6, Gender);
            preparedStatement.setString(7, DateOfBirth);
            preparedStatement.setString(8, Medications);
            preparedStatement.setString(9, Allergies);
            

            System.out.println(preparedStatement);
            // Step 3: Execute the query or update query
            preparedStatement.executeUpdate();
       
    }
    
    public String[] getDoctorsNames(String specialty) throws SQLException {
    	
 
   	            // Step 2:Create a statement using connection object
   	            PreparedStatement preparedStatement = connection.prepareStatement(Doctor_Names);
   	            	preparedStatement.setString(1, specialty);
   	            	ResultSet resultSet = preparedStatement.executeQuery();
   	            	
    				ArrayList<String> result1 = new ArrayList<>();
    				while(resultSet.next()) {
    					result1.add(resultSet.getString("username"));
    				}
    				String[] result = new String[result1.size()];
    				result = result1.toArray(result);
    				return result;
    }
    
    
    public void insertRec(String username, String password, String gender, String dateOfJoining, String bloodGroup, String Speciality) throws SQLException {
   	


   	            // Step 2:Create a statement using connection object
   	            PreparedStatement preparedStatement = connection.prepareStatement(AdminInsertingQUERY);
   	            preparedStatement.setString(1, username);
   	            preparedStatement.setString(2, password);
   	            preparedStatement.setString(3, gender);
   	            preparedStatement.setString(4, dateOfJoining);
   	            preparedStatement.setString(5, bloodGroup);
   	            preparedStatement.setString(6, Speciality);
   	    
   	            

   	            System.out.println(preparedStatement);
   	            // Step 3: Execute the query or update query
   	            preparedStatement.executeUpdate();
   	       }
    public boolean loginPatients(String username, String password) throws SQLException {
    	

                PreparedStatement preparedStatement = connection.prepareStatement(LOGIN_QUERY);
                preparedStatement.setString(1, username);
                preparedStatement.setString(2, password);


                ResultSet resultSet = preparedStatement.executeQuery();
                if (resultSet.next()) {
                	Login.id = resultSet.getInt("patient_id");
                	return true;
                }
                return false;   
        }
    public boolean loginDoctors(String username, String password) throws SQLException {
    	

        PreparedStatement preparedStatement = connection.prepareStatement(InsertingQUERY);
        preparedStatement.setString(1, username);
        preparedStatement.setString(2, password);


        ResultSet resultSet = preparedStatement.executeQuery();
        if (resultSet.next()) {
        	DoctorLogin.id = resultSet.getInt("doctor_id");
        	return true;
        }
        return false;   
}
    public void bookAppointment(int patientId, int doctorId, String start, String end, String day) throws SQLException {
    	PreparedStatement preparedStatement = connection.prepareStatement(BOOK_APPOINMENT);
    	
    	preparedStatement.setString(1, start);
    	preparedStatement.setString(2, end);
    	preparedStatement.setString(3, day);
    	preparedStatement.setInt(4, patientId);
    	preparedStatement.setInt(5, doctorId);
    	
    	
    	
    	preparedStatement.executeUpdate();
    }
    
    public String[] check_appointments(String day, int doctorId) throws SQLException {
    	ArrayList<String> resultAsAL= new ArrayList<>();
    	PreparedStatement preparedStatement = connection.prepareStatement(CHECK_APPOINMENT);
    	preparedStatement.setString(1, day);
    	preparedStatement.setInt(2, doctorId);
    	
    	ResultSet resultSet = preparedStatement.executeQuery();
    	while(resultSet.next()) {
    		resultAsAL.add(resultSet.getString("start_time"));
    	}
    	String[] result = new String[resultAsAL.size()];
		result = resultAsAL.toArray(result);
		return result;
    	
    }
    
    public int getDoctorId(String username, String specialty) throws SQLException {
    	int doc_id = 0;
    	PreparedStatement prep = connection.prepareStatement(DOCTOR_ID_QUERY);
    	prep.setString(1, username);
    	prep.setString(2, specialty);
    	
    	ResultSet resultSet = prep.executeQuery();
    	while(resultSet.next()) {
    		doc_id = resultSet.getInt("doctor_id");
    	}
    	return doc_id;
    	
    }

    public static void printSQLException(SQLException ex) {
        for (Throwable e: ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
}