package application;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;

	public class appointments implements Initializable{
	@FXML
    private DatePicker Day_Slot;

    @FXML
    private ChoiceBox<?> Department;

    @FXML
    private ChoiceBox<?> Doctor_name;

    @FXML
    private ChoiceBox<?> Time_Slot;

    @FXML
    private Button back;
    
    Main sc = new Main();
	
    String department[] = {"Heart", "Bones"};
    
    public appointments() {
    	
    	//Department.getItems().addAll(department);
    }
    
    public void initialize(URL arg0, ResourceBundle arg1) {
    	//Department.setValue("None");
    	//Department.getItems().addAll(department);
		
	}
	@FXML
	void Undo(ActionEvent event) throws IOException {
	sc.changeScene("Login.fxml");
	}
}
