package application;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.awt.*;
import javafx.scene.control.Label;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.input.InputMethodEvent;

	public class BookingAnAppointment extends PatientProfile implements Initializable{
	
		@FXML
	    private DatePicker Day_Slot;

	    @FXML
	    private ChoiceBox<String> Department;

	    @FXML
	    private ChoiceBox<String> Doctor_name;

	    @FXML
	    private ChoiceBox<String> Time_Slot;
	    
	    @FXML
	    private Label TimeLabel;
	    
	    @FXML
	    private Button BookAnAppointment;
	    
	    @FXML
	    private Button Profile;
	    
	    @FXML
	    private Button Signout;
	    
	    @FXML
	    private Button BookAppointment;
	    
	    @FXML
	    private Label DoctorLabel;
	    
	    @FXML
	    private Label DayLabel;
	    
	    @FXML
	    private Label DepartmentLabel;
	    
	    public static int doc_id;
	    
	    DatabaseConnection jdb = DatabaseConnection.getInstance();
	    
	    Main sc = new Main();
	    String[] PatientInfo;
    	String [] DoctorInfo;
		
	    String[] department = {"Neurologist", "Psychiatrist",  "Dermatology","Cardiologist", "Orthopedic"};
	    String [] TimesAvailable = {"8:00 am","9:00 am","10:00 am","11:00 am","12:00 pm","1:00 pm","2:00 pm","3:00 pm","4:00 pm","5:00 pm"};
	    HashMap<String, String> timeMap = new HashMap<>();
	  
	    String[] toRemove;

	    GmailSender sendmail = new GmailSender();
	    
	    String PatientEmail, DoctorEmail;
	    
	    
	    public BookingAnAppointment() {
	    	
	    	
	    }
	    public void initialize(URL arg0, ResourceBundle arg1) {
	    	BookAnAppointment.getStyleClass().add("bookAppointments");	
	    	timeMap.put("8:00 am", "9:00 am");
	    	timeMap.put("9:00 am", "10:00 am");
	    	timeMap.put("10:00 am", "11:00 am");
	    	timeMap.put("11:00 am", "12:00 pm");
	    	timeMap.put("12:00 pm", "1:00 pm");
	    	timeMap.put("1:00 pm", "2:00 pm");
	    	timeMap.put("2:00 pm", "3:00 pm");
	    	timeMap.put("3:00 pm", "4:00 pm");
	    	timeMap.put("4:00 pm", "5:00 pm");
	    	timeMap.put("5:00 pm", "6:00 pm");
	    	Department.getItems().addAll(department);
	    	Time_Slot.getItems().addAll(TimesAvailable);

	    	Department.getSelectionModel().selectedItemProperty().addListener
	    	( (ObservableValue<? extends String> observable, String oldValue, String newValue) -> Doctor_name.getItems().clear());
	    	Department.getSelectionModel().selectedItemProperty().addListener
	    	( (ObservableValue<? extends String> observable, String oldValue, String newValue)
	    			-> {
						try {
							Doctor_name.getItems().addAll(jdb.getDoctorsNames(newValue));
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					} );
	    	
	    	
			
		}
	    
	    @FXML
	    public void getDate(ActionEvent event) throws SQLException {
	    	Time_Slot.getItems().clear();
	    	doc_id = jdb.getDoctorId(Doctor_name.getValue(), Department.getValue());
	    	toRemove = jdb.check_appointments(Day_Slot.getValue().toString(), doc_id);
	    	Time_Slot.getItems().addAll(TimesAvailable);
	    	for(String time : toRemove) {
	    		System.out.println(time);
	    		Time_Slot.getItems().remove(time);
	    	}
	    }
	    
	    @FXML
	    void Book(ActionEvent event) throws SQLException, IOException {
	    	
	    	CheckifAllIsEmpty();
			CheckifOneIsEmpty();
			RemoveLabelIfFilled();
			if(CheckifAllIsEmpty() && CheckifOneIsEmpty()) {
	    	if(!jdb.checkTimeConflict(Login.id, Time_Slot.getValue(), Day_Slot.getValue().toString())) {
	        	String end = timeMap.get(Time_Slot.getValue());
	        	jdb.bookAppointment(Login.id, doc_id, Time_Slot.getValue(), end, Day_Slot.getValue().toString());
	        	sc.changeScene("BookingAppointment.fxml");
	        	try {
					PatientInfo = jdb.getPatientProfileInfo(Login.id);
					PatientEmail = PatientInfo[1];
					DoctorInfo = jdb.getDoctorProfileInfo(doc_id);
					DoctorEmail = DoctorInfo[0];
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	        	Thread newThread = new Thread(() -> {
	        		sendmail.send(DoctorEmail, "New Appointment", "Dear Dr. " + Doctor_name.getValue() +", \n" + "A new patient has registered for an appointment with you at " + Time_Slot.getValue().toString() + " on " +Day_Slot.getValue().toString() + "\nRegards.");
			    	sendmail.send(PatientEmail, "Registration Confirmed", "This is a confirmation email for your appointment at our hospital with Dr. " + Doctor_name.getValue().toString() + " at time " + Time_Slot.getValue().toString() + " on " +Day_Slot.getValue().toString()+ ". \nDon't hesitate to contact us for any issue by replying to this email.\nRegards,\nGeneral Manager");
		        	});
	            newThread.start();
	        	
	     
		    	//sendmail.send(DoctorEmail, "New Appointment", "Dear Dr. " + Doctor_name.getValue() +", \n" + "A new patient has registered for an appointment with you at " + Time_Slot.getValue().toString() + " on " +Day_Slot.getValue().toString() + "\nRegards.");
		    	//sendmail.send(PatientEmail, "Registration Confirmed", "This is a confirmation email for your appointment at our hospital with Dr. " + Doctor_name.getValue().toString() + " at time " + Time_Slot.getValue().toString() + " on " +Day_Slot.getValue().toString()+ ". \nDon't hesitate to contact us for any issue by replying to this email.\nRegards,\nGeneral Manager");
	        	}else {
	        		TimeLabel.setText("you have another appointment at this date\n and time with doctor \n" + jdb.getDoctorNameForAnAppoitment(Login.id, Time_Slot.getValue(), Day_Slot.getValue().toString()));
	        	}
			}
			else {
				CheckifAllIsEmpty();
	     		CheckifOneIsEmpty();
	     		RemoveLabelIfFilled();
			}
	    }
	    
	    private boolean CheckifAllIsEmpty() {
	    	if (Department.getValue()==null && Day_Slot.getValue()==null && Time_Slot.getValue()==null && Doctor_name.getValue()==null) {
	    		DoctorLabel.setText("Please choose a doctor");
		    	DayLabel.setText("Please choose a day");
		    	DepartmentLabel.setText("Please choose a department");
		    	TimeLabel.setText("Please choose a time");
	        	return false;
	    	}
			return true;
	    }
	    private boolean CheckifOneIsEmpty() {

	        boolean validTextFields = true;

	        if (Department.getValue()==null) {
	            validTextFields = false;
	            DepartmentLabel.setText("Please choose a department");
	        }

	        if (Day_Slot.getValue()==null) {
	            validTextFields = false;
	            DayLabel.setText("Please choose a day");
	        }
	        
	        if (Time_Slot.getValue()==null) {
	            validTextFields = false;
	            TimeLabel.setText("Please choose a time");
	            
	        }
	        
	        if (Doctor_name.getValue()==null) {
	            validTextFields = false;
	            DoctorLabel.setText("Please choose a doctor");
	        }

	        return validTextFields;
	    }
	    
	    private boolean RemoveLabelIfFilled() {
			boolean validTextFields = true;
			 
			
	        if (Department.getValue()!=null) {
	            validTextFields = false;
	            DepartmentLabel.setText("");
	            
	        }

	        if (Day_Slot.getValue()!=null) {
	            validTextFields = false;
	            DayLabel.setText("");
	            
	        }
	        
	        if (Time_Slot.getValue()!=null) {
	            validTextFields = false;
	            TimeLabel.setText("");
	            
	        }
	        
	        if (Doctor_name.getValue()!=null) {
	            validTextFields = false;
	            DoctorLabel.setText("");
	        }

	        return validTextFields;
		}
	}

